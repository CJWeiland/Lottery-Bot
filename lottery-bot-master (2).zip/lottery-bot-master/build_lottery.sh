cd lottery;
cargo build --release;
cp target/release/liblottery.so ../lottery.so
